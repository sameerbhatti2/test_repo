exports.Navlink = [
    {name:'Home', to:'/home'},
    {name:'Resume', to:'/Resume'},
    {name:'Portflio', to:'/Portflio'},
    {name:'Github', to:'/Github'},
    {name:'Contact', to:'/Contact'},
    {name:'Test', to:'/Test'},
    {name:'Test0', to:'/Test0'},
]